function [F, M] = controller(qd, t, params)
% CONTROLLER quadrotor controller
%
% INPUTS:
% qd     - 1 x n cell, qd structure, contains current and desired state
% t      - 1 x 1, time
% params - struct, output from crazyflie() and whatever parameters you want to pass in
%
% OUTPUTS:
% F      - 1 x 1, thrust (u1)
% M      - 3 x 1, moments (u2, u3, u4)

% Convert qd to state
[s] = qdToState(qd);

% Get desired state
pos_des = qd.pos_des;
vel_des = qd.vel_des;
acc_des = qd.acc_des;
psi_des = qd.yaw_des;
wx_des = 0;
wy_des = 0;
wz_des = qd.yawdot_des;

% Assign current states
x    = s(1); % Position
y    = s(2);
z    = s(3);
xdot = s(4); % Linear velocity
ydot = s(5);
zdot = s(6);
qW   = s(7); % Quaternion
qX   = s(8);
qY   = s(9);
qZ   = s(10);
wx   = s(11); % Angular velocity
wy   = s(12);
wz   = s(13);
Rot  = QuatToRot([qW; qX; qY; qZ]);
[phi, theta, psi] = RotToRPY_ZXY(Rot);

% Extract parameters of the robot
g = params.grav;
m = params.mass;
I = params.I;
L = params.arm_length;

%% YOUR CODE STARTS HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute desired linear accelerations


% Compute desired roll and pitch angle based on desired acceleration and yaw angle


% Compute force (u1)
u1 = 0;

% Compute moments (u2, u3, u4)
u2 = 0;
u3 = 0;
u4 = 0;

%% YOUR CODE ENDS HERE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Set outputs
F = u1;
M = [u2; u3; u4];

end
